package com.omar.osmtransfer

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.omar.osmtransfer.data.SalesDatabase
import com.omar.osmtransfer.databinding.ActivitySalesHistoryBinding
import com.omar.osmtransfer.pricing.MarketMode
import com.omar.osmtransfer.settings.AppSettings
import java.text.DateFormat
import java.util.Date

class SalesHistoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySalesHistoryBinding
    private lateinit var db: SalesDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySalesHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = SalesDatabase(this)

        binding.saveSaleButton.setOnClickListener {
            val power = binding.powerInput.text.toString().toIntOrNull()
            val value = binding.valueInput.text.toString().replace(',', '.').toDoubleOrNull()
            val price = binding.priceInput.text.toString().replace(',', '.').toDoubleOrNull()
            val age = binding.ageInput.text.toString().toIntOrNull()
            val hours = binding.hoursInput.text.toString().replace(',', '.').toDoubleOrNull()
            if (power == null || value == null || price == null || value <= 0 || price <= 0) {
                binding.historyText.text = "اكتب الباور والقيمة والسعر بشكل صحيح."
                return@setOnClickListener
            }
            db.insert(
                binding.nameInput.text.toString().ifBlank { null }, power, age, value, price,
                binding.soldSwitch.isChecked, hours, AppSettings.marketMode(this)
            )
            binding.nameInput.text?.clear(); binding.powerInput.text?.clear(); binding.ageInput.text?.clear()
            binding.valueInput.text?.clear(); binding.priceInput.text?.clear(); binding.hoursInput.text?.clear()
            renderHistory()
        }
        renderHistory()
    }

    private fun renderHistory() {
        val rows = db.latest(40)
        if (rows.isEmpty()) {
            binding.historyText.text = "لا توجد صفقات مسجلة بعد. كل صفقة تسجلها تساعد وضع التعلم الشخصي."
            return
        }
        binding.historyText.text = buildString {
            append("آخر ${rows.size} صفقة\n\n")
            rows.forEach { r ->
                val date = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(r.createdAt))
                val state = if (r.sold) "اتباع" else "لم يُبع"
                val mode = if (r.mode == MarketMode.WINNERS_CUP) "كأس" else "دوري"
                append("$date • ${r.playerName ?: "لاعب"} • OVR ${r.power}\n")
                append("${"%.1f".format(r.valueM)}M → ${"%.1f".format(r.listedM)}M • $state • $mode")
                r.hours?.let { append(" • ${"%.1f".format(it)}س") }
                append("\n\n")
            }
        }
    }
}
