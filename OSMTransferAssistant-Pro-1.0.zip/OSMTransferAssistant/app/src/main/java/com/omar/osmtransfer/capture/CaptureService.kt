package com.omar.osmtransfer.capture

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.omar.osmtransfer.data.SalesDatabase
import com.omar.osmtransfer.ocr.OsmTextParser
import com.omar.osmtransfer.overlay.OverlayController
import com.omar.osmtransfer.pricing.PricingEngine
import com.omar.osmtransfer.settings.AppSettings
import com.omar.osmtransfer.util.SnapshotStabilizer
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "com.omar.osmtransfer.START"
        const val ACTION_STOP = "com.omar.osmtransfer.STOP"
        const val ACTION_STATUS = "com.omar.osmtransfer.STATUS"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_STATUS = "status"
        private const val CHANNEL_ID = "capture"
        private const val NOTIFICATION_ID = 7
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private lateinit var overlay: OverlayController
    private lateinit var db: SalesDatabase
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val processing = AtomicBoolean(false)
    private val stabilizer = SnapshotStabilizer(4)
    private var lastProcessedAt = 0L
    private var lastValidAt = 0L
    private lateinit var workerThread: HandlerThread
    private lateinit var workerHandler: Handler

    override fun onCreate() {
        super.onCreate()
        overlay = OverlayController(this)
        db = SalesDatabase(this)
        workerThread = HandlerThread("osm-capture").also { it.start() }
        workerHandler = Handler(workerThread.looper)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_START -> startCapture(intent)
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        )
        if (mediaProjection != null) return

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data: Intent = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        } ?: run { stopSelf(); return }

        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mgr.getMediaProjection(resultCode, data)
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, workerHandler)

        val metrics = if (Build.VERSION.SDK_INT >= 30) {
            val bounds = (getSystemService(Context.WINDOW_SERVICE) as WindowManager).maximumWindowMetrics.bounds
            Triple(bounds.width(), bounds.height(), resources.configuration.densityDpi)
        } else {
            val dm = resources.displayMetrics
            Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
        }
        val width = metrics.first
        val height = metrics.second
        val density = metrics.third

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val now = System.currentTimeMillis()
            if (now - lastProcessedAt < 650 || !processing.compareAndSet(false, true)) {
                reader.acquireLatestImage()?.close(); return@setOnImageAvailableListener
            }
            lastProcessedAt = now
            val image = reader.acquireLatestImage() ?: run { processing.set(false); return@setOnImageAvailableListener }

            val bitmap = try {
                imageToBitmap(image.planes[0].buffer, width, height, image.planes[0].pixelStride, image.planes[0].rowStride)
            } finally { image.close() }

            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { text ->
                    val raw = OsmTextParser.parse(text, width, height)
                    val stable = stabilizer.push(raw)
                    if (stable?.marketValueM != null && stable.power != null && stable.confidence >= 0.62f) {
                        val mode = AppSettings.marketMode(this)
                        val personal = if (AppSettings.adaptivePricing(this)) db.adaptiveStats(stable.power, mode) else null
                        val bands = PricingEngine.calculate(
                            stable.marketValueM, stable.power, stable.age, mode,
                            AppSettings.seasonPhase(this), AppSettings.transferEvent(this), personal
                        )
                        overlay.showOrUpdate(stable, bands)
                        lastValidAt = System.currentTimeMillis()
                        broadcast("تمت قراءة لاعب: OVR ${stable.power} • ${"%.1f".format(stable.marketValueM)}M")
                    } else if (System.currentTimeMillis() - lastValidAt > 4500) {
                        overlay.hide()
                        broadcast("القارئ يعمل — افتح شاشة بيع لاعب")
                    }
                }
                .addOnFailureListener { broadcast("تعذر تحليل هذه اللقطة، سيحاول تلقائيًا") }
                .addOnCompleteListener { bitmap.recycle(); processing.set(false) }
        }, workerHandler)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "OSMTransferCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, workerHandler
        )
        broadcast("القارئ المباشر يعمل")
    }

    private fun imageToBitmap(buffer: ByteBuffer, width: Int, height: Int, pixelStride: Int, rowStride: Int): Bitmap {
        val rowPadding = rowStride - pixelStride * width
        val paddedWidth = width + rowPadding / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        return if (paddedWidth == width) padded else Bitmap.createBitmap(padded, 0, 0, width, height).also { padded.recycle() }
    }

    private fun broadcast(status: String) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra(EXTRA_STATUS, status))
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, CaptureService::class.java).apply { action = ACTION_STOP }
        val pending = PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("OSM Transfer Assistant Pro")
            .setContentText("القارئ الذكي يعمل فوق OSM")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(0, "إيقاف", pending)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "OSM live reader", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        overlay.hide()
        imageReader?.close(); imageReader = null
        virtualDisplay?.release(); virtualDisplay = null
        mediaProjection?.stop(); mediaProjection = null
        recognizer.close()
        workerThread.quitSafely()
        broadcast("تم إيقاف القارئ")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
