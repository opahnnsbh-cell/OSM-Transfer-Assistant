package com.omar.osmtransfer.pricing

import com.omar.osmtransfer.data.AdaptiveStats
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

enum class MarketMode { NORMAL, WINNERS_CUP }
enum class SeasonPhase { EARLY, MID, LATE }

data class PriceBands(
    val quickM: Double,
    val balancedM: Double,
    val profitM: Double,
    val riskM: Double,
    val maxM: Double,
    val recommendedLabel: String,
    val modelNote: String
)

object PricingEngine {
    fun calculate(
        valueM: Double,
        power: Int,
        age: Int?,
        mode: MarketMode,
        season: SeasonPhase,
        transferEvent: Boolean,
        adaptive: AdaptiveStats? = null
    ): PriceBands {
        val maxPrice = valueM * 2.5

        // Deterministic heuristic. It intentionally never pretends to know OSM's private sale algorithm.
        val strengthPenalty = when {
            power < 80 -> 0.00
            power < 85 -> 0.03
            power < 90 -> 0.07
            power < 95 -> 0.12
            power < 100 -> 0.18
            power < 105 -> 0.24
            power < 110 -> 0.30
            power < 115 -> 0.36
            power < 120 -> 0.41
            else -> 0.46
        }
        val valuePenalty = when {
            valueM < 5 -> 0.00
            valueM < 15 -> 0.04
            valueM < 30 -> 0.09
            valueM < 60 -> 0.15
            else -> 0.20
        }
        val ageBoost = when {
            age == null -> 0.0
            age <= 21 -> 0.04
            age <= 25 -> 0.02
            age >= 31 -> -0.03
            else -> 0.0
        }
        val cupPenalty = if (mode == MarketMode.WINNERS_CUP) 0.08 else 0.0
        val seasonShift = when (season) {
            SeasonPhase.EARLY -> 0.08
            SeasonPhase.MID -> 0.0
            SeasonPhase.LATE -> -0.07
        }
        val eventBoost = if (transferEvent) 0.18 else 0.0

        // Personal-history correction after enough successful samples in this power bucket.
        val adaptiveShift = adaptive?.takeIf { it.samples >= 5 }
            ?.let { ((it.averageMultiplier - 1.80) * 0.30).coerceIn(-0.12, 0.12) } ?: 0.0

        fun price(base: Double): Double {
            val multiplier = (base - strengthPenalty - valuePenalty - cupPenalty + ageBoost + seasonShift + eventBoost + adaptiveShift)
                .coerceIn(1.02, 2.49)
            return round1(min(maxPrice, max(valueM, valueM * multiplier)))
        }

        val quick = price(1.58)
        val balanced = max(quick, price(1.88))
        val profit = max(balanced, price(2.18))
        val risk = max(profit, price(2.42))
        val adaptiveNote = if (adaptive != null && adaptive.samples >= 5) "تعلم شخصي: ${adaptive.samples} صفقة" else "نموذج أساسي"

        return PriceBands(
            quickM = quick,
            balancedM = balanced,
            profitM = profit,
            riskM = risk,
            maxM = round1(maxPrice),
            recommendedLabel = if (transferEvent) "ربح" else "متوازن",
            modelNote = adaptiveNote
        )
    }

    private fun round1(v: Double) = round(v * 10.0) / 10.0
}
