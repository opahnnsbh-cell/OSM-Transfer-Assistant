package com.omar.osmtransfer.model

data class PlayerSnapshot(
    val name: String? = null,
    val age: Int? = null,
    val power: Int? = null,
    val marketValueM: Double? = null,
    val currentPriceM: Double? = null,
    val confidence: Float = 0f,
    val rawText: String = "",
    val screenWidth: Int = 0,
    val screenHeight: Int = 0
)
