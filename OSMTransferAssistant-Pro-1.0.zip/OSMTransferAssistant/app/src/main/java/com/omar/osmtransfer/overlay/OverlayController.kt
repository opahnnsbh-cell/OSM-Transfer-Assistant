package com.omar.osmtransfer.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import com.omar.osmtransfer.model.PlayerSnapshot
import com.omar.osmtransfer.pricing.PriceBands
import com.omar.osmtransfer.settings.AppSettings

class OverlayController(private val context: Context) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: PriceOverlayView? = null

    fun showOrUpdate(snapshot: PlayerSnapshot, bands: PriceBands) {
        if (!Settings.canDrawOverlays(context)) return
        if (view == null) {
            view = PriceOverlayView(context)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            wm.addView(view, params)
        }
        view?.update(snapshot, bands, AppSettings.calibration(context), AppSettings.overlayCompact(context))
    }

    fun hide() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }
}
