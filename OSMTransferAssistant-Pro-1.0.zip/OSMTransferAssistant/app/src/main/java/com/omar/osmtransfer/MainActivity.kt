package com.omar.osmtransfer

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.omar.osmtransfer.capture.CaptureService
import com.omar.osmtransfer.databinding.ActivityMainBinding
import com.omar.osmtransfer.settings.AppSettings

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                action = CaptureService.ACTION_START
                putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(CaptureService.EXTRA_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, service)
            binding.statusText.text = "القارئ يعمل. افتح OSM ثم شاشة بيع لاعب."
        } else binding.statusText.text = "لم يتم منح إذن قراءة الشاشة."
    }
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            binding.statusText.text = intent?.getStringExtra(CaptureService.EXTRA_STATUS) ?: return
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val prefs = AppSettings.prefs(this)

        binding.winnersMode.isChecked = prefs.getBoolean("winners", false)
        binding.normalMode.isChecked = !binding.winnersMode.isChecked
        binding.transferEventSwitch.isChecked = prefs.getBoolean("event", false)
        binding.adaptiveSwitch.isChecked = prefs.getBoolean("adaptive", true)
        binding.compactSwitch.isChecked = prefs.getBoolean("compact_overlay", false)
        binding.seasonPhase.setSelection(prefs.getInt("season_phase", 1))

        binding.modeGroup.setOnCheckedChangeListener { _, id -> prefs.edit().putBoolean("winners", id == R.id.winnersMode).apply() }
        binding.transferEventSwitch.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("event", v).apply() }
        binding.adaptiveSwitch.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("adaptive", v).apply() }
        binding.compactSwitch.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("compact_overlay", v).apply() }
        binding.seasonPhase.onItemSelectedListener = SimpleItemSelectedListener { position -> prefs.edit().putInt("season_phase", position).apply() }

        binding.overlayPermissionButton.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else binding.statusText.text = "إذن الظهور فوق التطبيقات مفعّل."
        }
        binding.calibrationButton.setOnClickListener { startActivity(Intent(this, CalibrationActivity::class.java)) }
        binding.historyButton.setOnClickListener { startActivity(Intent(this, SalesHistoryActivity::class.java)) }

        binding.startButton.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) { binding.statusText.text = "فعّل إذن الظهور فوق التطبيقات أولًا."; return@setOnClickListener }
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mgr.createScreenCaptureIntent())
        }
        binding.stopButton.setOnClickListener {
            startService(Intent(this, CaptureService::class.java).apply { action = CaptureService.ACTION_STOP })
            binding.statusText.text = "تم إيقاف القارئ."
        }
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(this, statusReceiver, IntentFilter(CaptureService.ACTION_STATUS), ContextCompat.RECEIVER_NOT_EXPORTED)
    }
    override fun onStop() { runCatching { unregisterReceiver(statusReceiver) }; super.onStop() }
}

class SimpleItemSelectedListener(private val onSelected: (Int) -> Unit) : android.widget.AdapterView.OnItemSelectedListener {
    override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) = onSelected(position)
    override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
}
