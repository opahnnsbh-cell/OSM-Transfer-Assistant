package com.omar.osmtransfer.ocr

import android.graphics.Rect
import com.google.mlkit.vision.text.Text
import com.omar.osmtransfer.model.PlayerSnapshot
import kotlin.math.abs

object OsmTextParser {
    private val money = Regex("""(\d{1,3}(?:[.,]\d)?)\s*[Mm]""")
    private val ageRegex = Regex("""(?:العمر|age)\s*[:：]?\s*(\d{1,2})""", RegexOption.IGNORE_CASE)

    private fun normalizeDigits(input: String): String {
        val arabic = "٠١٢٣٤٥٦٧٨٩"
        val eastern = "۰۱۲۳۴۵۶۷۸۹"
        return buildString {
            input.forEach { ch ->
                val a = arabic.indexOf(ch)
                val e = eastern.indexOf(ch)
                append(when {
                    a >= 0 -> ('0'.code + a).toChar()
                    e >= 0 -> ('0'.code + e).toChar()
                    ch == '٫' || ch == ',' -> '.'
                    else -> ch
                })
            }
        }
    }

    fun parse(result: Text, width: Int, height: Int): PlayerSnapshot {
        data class Item(val text: String, val box: Rect)
        val items = result.textBlocks.flatMap { b -> b.lines.mapNotNull { l -> l.boundingBox?.let { Item(normalizeDigits(l.text), it) } } }
        val all = normalizeDigits(result.text)
        val ageExplicit = ageRegex.find(all)?.groupValues?.getOrNull(1)?.toIntOrNull()

        val values = items.mapNotNull { item ->
            money.find(item.text)?.groupValues?.getOrNull(1)?.toDoubleOrNull()?.let {
                Triple(it, item.box.centerX(), item.box.centerY())
            }
        }

        val cardValue = values
            .filter { (_, x, y) -> x > width * 0.58 && y > height * 0.58 }
            .minByOrNull { (_, x, y) -> abs(x - width * 0.73) + abs(y - height * 0.76) }
            ?.first
            ?: values.filter { it.first in 0.1..500.0 }.maxByOrNull { it.first }?.first

        val currentPrice = values
            .filter { (_, x, y) -> x < width * 0.60 && y in (height * 0.45).toInt()..(height * 0.78).toInt() }
            .minByOrNull { (_, x, y) -> abs(x - width * 0.20) + abs(y - height * 0.62) }
            ?.first

        val numeric = items.mapNotNull { item ->
            Regex("""(?<![\d.])(\d{2,3})(?![\d.])""").find(item.text)?.groupValues?.getOrNull(1)?.toIntOrNull()?.let {
                Triple(it, item.box.centerX(), item.box.centerY())
            }
        }

        val power = numeric
            .filter { (n, x, y) -> n in 50..200 && x > width * 0.52 && y in (height * 0.32).toInt()..(height * 0.82).toInt() }
            .filterNot { (n, _, _) -> ageExplicit != null && n == ageExplicit }
            .minByOrNull { (_, x, y) -> abs(x - width * 0.69) + abs(y - height * 0.58) }
            ?.first

        val age = ageExplicit ?: numeric
            .filter { (n, x, y) -> n in 16..45 && x > width * 0.58 && y < height * 0.55 }
            .minByOrNull { (_, x, y) -> abs(x - width * 0.77) + abs(y - height * 0.34) }
            ?.first

        val name = items
            .filter { it.box.centerX() > width * 0.55 && it.box.centerY() < height * 0.45 }
            .map { it.text.trim() }
            .firstOrNull { t -> t.length >= 3 && t.any(Char::isLetter) && !t.contains("العمر", true) && !t.contains("age", true) }

        var score = 0f
        if (power != null) score += 0.42f
        if (cardValue != null) score += 0.38f
        if (age != null) score += 0.10f
        if (name != null) score += 0.10f

        return PlayerSnapshot(name, age, power, cardValue, currentPrice, score, all.take(1000), width, height)
    }
}
