package com.omar.osmtransfer.util

import com.omar.osmtransfer.model.PlayerSnapshot
import java.util.ArrayDeque

class SnapshotStabilizer(private val capacity: Int = 4) {
    private val frames = ArrayDeque<PlayerSnapshot>()

    fun push(s: PlayerSnapshot): PlayerSnapshot? {
        frames.addLast(s)
        while (frames.size > capacity) frames.removeFirst()
        if (frames.size < 2) return null

        fun stableInt(get: (PlayerSnapshot) -> Int?): Int? = frames.mapNotNull(get)
            .groupingBy { it }.eachCount().maxByOrNull { it.value }?.takeIf { it.value >= 2 }?.key
        fun stableDouble(get: (PlayerSnapshot) -> Double?): Double? = frames.mapNotNull(get)
            .map { kotlin.math.round(it * 10.0) / 10.0 }
            .groupingBy { it }.eachCount().maxByOrNull { it.value }?.takeIf { it.value >= 2 }?.key

        val power = stableInt { it.power } ?: return null
        val value = stableDouble { it.marketValueM } ?: return null
        val latest = frames.last()
        return latest.copy(
            power = power,
            age = stableInt { it.age } ?: latest.age,
            marketValueM = value,
            currentPriceM = stableDouble { it.currentPriceM } ?: latest.currentPriceM,
            confidence = (frames.map { it.confidence }.average().toFloat() + 0.12f).coerceAtMost(1f)
        )
    }

    fun clear() = frames.clear()
}
