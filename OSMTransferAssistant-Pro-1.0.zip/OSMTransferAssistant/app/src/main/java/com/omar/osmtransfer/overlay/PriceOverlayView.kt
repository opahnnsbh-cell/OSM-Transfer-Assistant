package com.omar.osmtransfer.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import com.omar.osmtransfer.model.PlayerSnapshot
import com.omar.osmtransfer.pricing.PriceBands
import com.omar.osmtransfer.settings.Calibration

class PriceOverlayView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var snapshot: PlayerSnapshot? = null
    private var bands: PriceBands? = null
    private var calibration = Calibration(0.265f, 0.552f, 0.617f)
    private var compact = false

    fun update(snapshot: PlayerSnapshot, bands: PriceBands, calibration: Calibration, compact: Boolean) {
        this.snapshot = snapshot
        this.bands = bands
        this.calibration = calibration
        this.compact = compact
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val s = snapshot ?: return
        val b = bands ?: return
        val value = s.marketValueM ?: return
        if (calibration.sliderRight <= calibration.sliderLeft + 0.05f) return

        val left = width * calibration.sliderLeft
        val right = width * calibration.sliderRight
        val y = height * calibration.sliderY

        fun xFor(price: Double): Float {
            val denominator = (b.maxM - value).coerceAtLeast(0.1)
            val ratio = ((price - value) / denominator).coerceIn(0.0, 1.0)
            return left + (right - left) * ratio.toFloat()
        }

        // translucent guide rail
        paint.color = 0x5538E7FF
        paint.strokeWidth = 2f
        canvas.drawLine(left, y, right, y, paint)

        val labels = listOf(
            Triple("سريع", b.quickM, 0xFF22D69B.toInt()),
            Triple("متوازن", b.balancedM, 0xFF31C7F0.toInt()),
            Triple("ربح", b.profitM, 0xFFFFC857.toInt()),
            Triple("مخاطرة", b.riskM, 0xFFFF6B6B.toInt())
        )

        labels.forEachIndexed { index, (label, price, color) ->
            val x = xFor(price)
            paint.color = color
            paint.strokeWidth = if (label == b.recommendedLabel) 6f else 4f
            canvas.drawLine(x, y - 38f, x, y + 38f, paint)
            canvas.drawCircle(x, y, 7f, paint)

            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textSize = if (compact) 19f else 23f
            val text = "$label ${"%.1f".format(price)}M"
            val tw = paint.measureText(text)
            val ty = y - 46f - index * (if (compact) 23f else 27f)
            paint.style = Paint.Style.FILL
            paint.color = 0xE80A1726.toInt()
            canvas.drawRoundRect(RectF(x - tw / 2 - 9, ty - 24, x + tw / 2 + 9, ty + 7), 10f, 10f, paint)
            paint.color = color
            canvas.drawText(text, x - tw / 2, ty, paint)
        }

        if (!compact) {
            val panel = RectF(width * 0.018f, height * 0.035f, width * 0.34f, height * 0.145f)
            paint.color = 0xD90A1726.toInt()
            canvas.drawRoundRect(panel, 16f, 16f, paint)
            paint.color = 0xFFFFFFFF.toInt()
            paint.textSize = 22f
            paint.typeface = Typeface.DEFAULT_BOLD
            val title = s.name?.take(24) ?: "Player detected"
            canvas.drawText(title, panel.left + 16f, panel.top + 30f, paint)
            paint.textSize = 18f
            paint.typeface = Typeface.DEFAULT
            val info = "OVR ${s.power ?: "?"}  •  Age ${s.age ?: "?"}  •  Value ${"%.1f".format(value)}M"
            canvas.drawText(info, panel.left + 16f, panel.top + 58f, paint)
            val confidence = (s.confidence * 100).toInt().coerceIn(0, 100)
            paint.color = if (confidence >= 75) 0xFF22D69B.toInt() else 0xFFFFC857.toInt()
            canvas.drawText("قراءة $confidence%  •  ${b.modelNote}", panel.left + 16f, panel.top + 84f, paint)
        }
    }
}
