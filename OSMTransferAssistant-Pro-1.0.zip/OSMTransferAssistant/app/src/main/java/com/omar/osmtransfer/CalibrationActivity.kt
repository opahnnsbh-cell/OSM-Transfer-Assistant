package com.omar.osmtransfer

import android.os.Bundle
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.omar.osmtransfer.databinding.ActivityCalibrationBinding
import com.omar.osmtransfer.settings.AppSettings
import com.omar.osmtransfer.settings.Calibration

class CalibrationActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCalibrationBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCalibrationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val c = AppSettings.calibration(this)
        binding.leftSeek.progress = (c.sliderLeft * 1000).toInt()
        binding.rightSeek.progress = (c.sliderRight * 1000).toInt()
        binding.ySeek.progress = (c.sliderY * 1000).toInt()
        updateLabels()

        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = updateLabels()
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        }
        binding.leftSeek.setOnSeekBarChangeListener(listener)
        binding.rightSeek.setOnSeekBarChangeListener(listener)
        binding.ySeek.setOnSeekBarChangeListener(listener)

        binding.resetButton.setOnClickListener {
            binding.leftSeek.progress = 265
            binding.rightSeek.progress = 552
            binding.ySeek.progress = 617
            updateLabels()
        }
        binding.saveButton.setOnClickListener {
            var left = binding.leftSeek.progress / 1000f
            var right = binding.rightSeek.progress / 1000f
            val y = binding.ySeek.progress / 1000f
            if (right <= left + 0.05f) right = (left + 0.10f).coerceAtMost(0.97f)
            AppSettings.saveCalibration(this, Calibration(left, right, y))
            finish()
        }
    }

    private fun updateLabels() {
        binding.leftLabel.text = "بداية الشريط: ${binding.leftSeek.progress / 10f}%"
        binding.rightLabel.text = "نهاية الشريط: ${binding.rightSeek.progress / 10f}%"
        binding.yLabel.text = "ارتفاع الشريط: ${binding.ySeek.progress / 10f}%"
    }
}
