package com.omar.osmtransfer.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.omar.osmtransfer.pricing.MarketMode

data class SaleRecord(
    val id: Long,
    val createdAt: Long,
    val playerName: String?,
    val power: Int,
    val age: Int?,
    val valueM: Double,
    val listedM: Double,
    val sold: Boolean,
    val hours: Double?,
    val mode: MarketMode
)

data class AdaptiveStats(val samples: Int, val averageMultiplier: Double)

class SalesDatabase(context: Context) : SQLiteOpenHelper(context, "sales.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE sales(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at INTEGER NOT NULL,
                player_name TEXT,
                power INTEGER NOT NULL,
                age INTEGER,
                value_m REAL NOT NULL,
                listed_m REAL NOT NULL,
                sold INTEGER NOT NULL,
                hours REAL,
                mode TEXT NOT NULL
            )""".trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun insert(
        playerName: String?, power: Int, age: Int?, valueM: Double,
        listedM: Double, sold: Boolean, hours: Double?, mode: MarketMode
    ) {
        writableDatabase.insert("sales", null, ContentValues().apply {
            put("created_at", System.currentTimeMillis())
            put("player_name", playerName)
            put("power", power)
            if (age != null) put("age", age) else putNull("age")
            put("value_m", valueM)
            put("listed_m", listedM)
            put("sold", if (sold) 1 else 0)
            if (hours != null) put("hours", hours) else putNull("hours")
            put("mode", mode.name)
        })
    }

    fun latest(limit: Int = 50): List<SaleRecord> {
        val out = mutableListOf<SaleRecord>()
        readableDatabase.query(
            "sales", null, null, null, null, null, "created_at DESC", limit.toString()
        ).use { c ->
            while (c.moveToNext()) {
                out += SaleRecord(
                    id = c.getLong(c.getColumnIndexOrThrow("id")),
                    createdAt = c.getLong(c.getColumnIndexOrThrow("created_at")),
                    playerName = c.getString(c.getColumnIndexOrThrow("player_name")),
                    power = c.getInt(c.getColumnIndexOrThrow("power")),
                    age = c.getColumnIndexOrThrow("age").let { if (c.isNull(it)) null else c.getInt(it) },
                    valueM = c.getDouble(c.getColumnIndexOrThrow("value_m")),
                    listedM = c.getDouble(c.getColumnIndexOrThrow("listed_m")),
                    sold = c.getInt(c.getColumnIndexOrThrow("sold")) == 1,
                    hours = c.getColumnIndexOrThrow("hours").let { if (c.isNull(it)) null else c.getDouble(it) },
                    mode = runCatching { MarketMode.valueOf(c.getString(c.getColumnIndexOrThrow("mode"))) }.getOrDefault(MarketMode.NORMAL)
                )
            }
        }
        return out
    }

    fun adaptiveStats(power: Int, mode: MarketMode): AdaptiveStats {
        val bucketMin = (power / 5) * 5
        val bucketMax = bucketMin + 4
        val sql = """
            SELECT COUNT(*) AS n, AVG(listed_m / value_m) AS avg_m
            FROM sales
            WHERE sold=1 AND power BETWEEN ? AND ? AND mode=? AND value_m > 0
        """.trimIndent()
        readableDatabase.rawQuery(sql, arrayOf(bucketMin.toString(), bucketMax.toString(), mode.name)).use { c ->
            if (c.moveToFirst()) {
                return AdaptiveStats(c.getInt(0), if (c.isNull(1)) 0.0 else c.getDouble(1))
            }
        }
        return AdaptiveStats(0, 0.0)
    }
}
