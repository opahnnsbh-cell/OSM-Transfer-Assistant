package com.omar.osmtransfer.settings

import android.content.Context
import com.omar.osmtransfer.pricing.MarketMode
import com.omar.osmtransfer.pricing.SeasonPhase

data class Calibration(
    val sliderLeft: Float,
    val sliderRight: Float,
    val sliderY: Float
)

object AppSettings {
    private const val PREFS = "settings"

    fun marketMode(context: Context): MarketMode =
        if (prefs(context).getBoolean("winners", false)) MarketMode.WINNERS_CUP else MarketMode.NORMAL

    fun seasonPhase(context: Context): SeasonPhase = when (prefs(context).getInt("season_phase", 1)) {
        0 -> SeasonPhase.EARLY
        2 -> SeasonPhase.LATE
        else -> SeasonPhase.MID
    }

    fun transferEvent(context: Context) = prefs(context).getBoolean("event", false)
    fun adaptivePricing(context: Context) = prefs(context).getBoolean("adaptive", true)
    fun overlayCompact(context: Context) = prefs(context).getBoolean("compact_overlay", false)

    fun calibration(context: Context): Calibration {
        val p = prefs(context)
        return Calibration(
            p.getFloat("slider_left", 0.265f).coerceIn(0.05f, 0.9f),
            p.getFloat("slider_right", 0.552f).coerceIn(0.10f, 0.97f),
            p.getFloat("slider_y", 0.617f).coerceIn(0.10f, 0.95f)
        )
    }

    fun saveCalibration(context: Context, c: Calibration) {
        prefs(context).edit()
            .putFloat("slider_left", c.sliderLeft)
            .putFloat("slider_right", c.sliderRight)
            .putFloat("slider_y", c.sliderY)
            .apply()
    }

    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
