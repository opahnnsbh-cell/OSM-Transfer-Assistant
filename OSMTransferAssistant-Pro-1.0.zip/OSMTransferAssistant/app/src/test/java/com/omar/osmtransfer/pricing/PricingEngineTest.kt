package com.omar.osmtransfer.pricing

import com.omar.osmtransfer.data.AdaptiveStats
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PricingEngineTest {
    @Test fun bandsAreOrderedAndBelowMax() {
        val b = PricingEngine.calculate(99.0, 114, 20, MarketMode.WINNERS_CUP, SeasonPhase.MID, false, null)
        assertTrue(b.quickM <= b.balancedM)
        assertTrue(b.balancedM <= b.profitM)
        assertTrue(b.profitM <= b.riskM)
        assertTrue(b.riskM <= b.maxM)
        assertEquals(247.5, b.maxM, 0.01)
    }

    @Test fun transferEventDoesNotLowerBalancedPrice() {
        val normal = PricingEngine.calculate(20.0, 95, 24, MarketMode.NORMAL, SeasonPhase.MID, false, null)
        val event = PricingEngine.calculate(20.0, 95, 24, MarketMode.NORMAL, SeasonPhase.MID, true, null)
        assertTrue(event.balancedM >= normal.balancedM)
    }

    @Test fun adaptiveModelOnlyMovesAfterEnoughSamples() {
        val lowSamples = PricingEngine.calculate(20.0, 100, 25, MarketMode.NORMAL, SeasonPhase.MID, false, AdaptiveStats(3, 2.2))
        val baseline = PricingEngine.calculate(20.0, 100, 25, MarketMode.NORMAL, SeasonPhase.MID, false, null)
        assertEquals(baseline.balancedM, lowSamples.balancedM, 0.01)
    }
}
