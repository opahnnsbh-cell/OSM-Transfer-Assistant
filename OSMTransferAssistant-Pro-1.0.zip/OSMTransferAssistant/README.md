# OSM Transfer Assistant Pro 1.0

Professional Android companion overlay for OSM transfer screens. It reads the visible player screen, stabilizes OCR across frames, estimates pricing bands, and draws live markers over the game's price slider.

## Features

- Live screen capture through Android MediaProjection with explicit user consent.
- Foreground `mediaProjection` service for Android 14/15-style requirements.
- Bundled Google ML Kit Latin text recognition model (no first-run OCR model download).
- Arabic-Indic / Eastern Arabic digit normalization for numeric parsing.
- Multi-frame stabilization to reduce jumping/wrong OCR values.
- Automatic overlay hide when no valid player screen is detected.
- Four price bands: Quick, Balanced, Profit, Risk.
- Normal League / Winners Cup market profiles.
- Early / Mid / Late season profiles.
- Transfer-event pricing modifier.
- Player age, power and absolute market-value adjustments.
- Device/layout calibration screen for slider start/end/Y coordinates.
- Compact and full overlay modes.
- Local SQLite sales history.
- Adaptive personal pricing after at least five successful sales in the same 5-OVR bucket and competition mode.
- No auto-tapping, auto-buying, auto-selling, or game control.

## Safety / accuracy model

OSM does not expose its private transfer-sale probability algorithm. The price engine is therefore a deterministic heuristic, not a guarantee. Personal-history adaptation only makes small bounded corrections after enough successful samples.

The app is designed as a companion/analytics overlay. It never presses game controls.

## Build

- Android Studio with Android SDK 35
- JDK 17
- Min Android version: API 26
- Target/compile SDK: 35

Open the root project folder in Android Studio, allow Gradle sync, then build/run the `app` module.

This archive intentionally does not claim to contain a prebuilt APK: the generation environment used for this source archive did not contain Android SDK/Gradle, so a device APK could not be honestly compiled or installed-tested here.

## First run

1. Open the app in landscape.
2. Choose Normal League or Winners Cup.
3. Choose season phase and whether a transfer event is active.
4. Open **Slider calibration**. The default values are based on the supplied 1536×691 OSM screenshot.
5. Grant “display over other apps”.
6. Start the professional reader and accept Android screen-capture consent.
7. Open OSM and a player sale screen. After two consistent OCR frames, the price overlay appears.
8. If marker positions are off, return to calibration and adjust the three normalized coordinates.

## Adaptive history

Use **Sales history** to record real listings. Record both successful and unsuccessful listings; successful sales contribute to the adaptive multiplier. The app only adapts after 5 successful records in the same 5-point OVR bucket and competition mode to avoid overfitting to one lucky sale.

## Project structure

- `capture/CaptureService.kt`: MediaProjection capture, throttling, OCR, stabilization, auto-hide.
- `ocr/OsmTextParser.kt`: screen-position-aware extraction and numeric normalization.
- `pricing/PricingEngine.kt`: deterministic price-band model and bounded adaptive correction.
- `overlay/*`: non-interactive full-screen overlay and slider markers.
- `settings/AppSettings.kt`: persistent market/calibration preferences.
- `data/SalesDatabase.kt`: local SQLite history and adaptive statistics.
- `CalibrationActivity.kt`: per-device slider calibration.
- `SalesHistoryActivity.kt`: manual result logging and history view.

## Privacy

The custom application code contains no analytics SDK and no custom network-upload code. Screen frames are processed for OCR and discarded. Sales history is stored locally in the app database.
